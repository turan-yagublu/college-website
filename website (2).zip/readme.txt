This is a website for a college called XYZ University. 
Through the website, you can look at the list of majors, and then by clicking on each major, you can look at the list of classes in that major. 
For now, I have only supplied computer science classes.
In the events section, one can look at all the upcoming events and purchase tickets. 
I am intending to add an authentication system where the user can sign up for an account to get discounts either as a student or faculty in the events section while buying tickets.